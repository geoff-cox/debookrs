Common Reg Ex Replacements
----------------------------------------------------------------------------
<tag> that needs an inline <subtag> tags
$1: space before tag
$2: tag name
$3: a space or end delimiter (>)
$4: tag attributes
$5: tag content
^([ \s]*)<(tag)(?=[\s>])([\s\S]*?)>([\s\S]*?)</tag>\n
$1<$2$3><subtag>$4</subtag></$2>\n
----------------------------------------------------------------------------
Tags that need multiline <p> tags
$1: space before tag
$2: tag name
$3: tag attributes
$4: tag content
^([ \s]*)<(tag)([\s\S]*?)>([\s\S]*?)</tag>\n
$1<$2$3>\n$1\t<p>\n$1\t\t$4\n$1\t</p>\n$1</$2>\n
----------------------------------------------------------------------------
Single to Multiline Paragraphs
(\t+)<p>(.*)</p>?
$1<p>\n$1\t$2\n$1</p>
----------------------------------------------------------------------------
Single Line Statements not beginning with <statement>
(\t*)(.*)<statement>(.*)</statement>?
$1$2\n$1\t<statement>\n$1\t\t<p>\n$1\t\t\t$3\n$1\t\t</p>\n$1\t</statement>
----------------------------------------------------------------------------
Removing Nested <p> tags (with newline and indention)
(\t+)<parentTag>\n(.*)<p>\n\t+(.*)\n(.*)</p>\n(.*)</parentTag>
$1<parentTag>\n$1\t$3\n$1</parentTag>
----------------------------------------------------------------------------
Removing Nested <p> tags (single line)
(\t+)<parentTag>\n(.*)<p>\n\t+(.*)\n(.*)</p>\n(.*)</parentTag>
$1<parentTag>$3</parentTag>
----------------------------------------------------------------------------
Converting tags to single line
^(\s+)<parentTag>\n\s+(.*)\n.*</parentTag>
$1<parentTag>$2</parentTag>
----------------------------------------------------------------------------
Removing the content from foo and bar tags
^([ \t]*)<(foo|bar)([\s\S]*?)>([\s\S]*?)</(foo|bar)>\n
$1<$2> temporarily omitted </$2>\n
----------------------------------------------------------------------------
Removing paragraphs from <statement> tags
^([ \t]*)<statement>\n\s*<p>\n*\s*([\s\S]*?)\n*\s*</p>\n\s*</statement>\n
$1<statement>$2</statement>\n
----------------------------------------------------------------------------
Removing paragraphs from <feedback> tags
^([ \t]*)<feedback>\n\s*<p>\n*\s*([\s\S]*?)\n*\s*</p>\n\s*</feedback>\n
$1<feedback>$2</feedback>\n
----------------------------------------------------------------------------
Remove comments <!-- * -->
<!--([\s\S]*?)-->\n
----------------------------------------------------------------------------
Convert **stuff** to <foo>stuff</foo>
\*\*(.*?)\*\*
<foo>$1</foo>
----------------------------------------------------------------------------
Replace **stuff**

**stuff** ➜ <foo>stuff</foo>
\*\*(.*?)\*\*
<foo>$1</foo>

----------------------------------------------------------------------------
Titles to next line
^(\s*)<(parentTag.*)><title> 
$1<$2>\n$1\t<title> 
----------------------------------------------------------------------------
Swap premises and responses
^([ \t]*)<premise>([\s\S]*?)</premise>\n\s*<response>([\s\S]*?)</response>
$1<premise>$3</premise>\n$1<response>$2</response>