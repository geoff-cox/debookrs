# TO-DO LIST:

- Replace details blocks with proofs
- Add assemblages to laplace rues and properties
- Convert checkpoint tasks to exercises
- Go through the common Laplace transforms section and make sure the detail drop-downs are fixed.