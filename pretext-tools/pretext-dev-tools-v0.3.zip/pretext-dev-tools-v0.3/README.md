# PreTeXt Dev Tools v0.3

This package is configured for the repository layout:

```
.vscode/
├── extension/
│   ├── extension.js
│   ├── package.json
│   └── media/pretext-dev.svg
├── scripts/
│   ├── toggle_xincludes.py
│   ├── toggle_xrefs.py
│   └── toggle_outcomes.py
├── settings.json
└── launch.json
source/
```

## Install/update

1. Replace the contents of `.vscode/extension/` with the files in `extension/`.
2. Copy `repo-config/launch.json` to `.vscode/launch.json` if you want to debug the extension while the repository root is open.
3. Keep your existing Python scripts in `.vscode/scripts/`.
4. After verifying all three toggles work, `.vscode/tasks.json` is no longer required for these tools and may be deleted if it contains no unrelated tasks.

## Activity Bar

The primary view contains:

- Toggle Includes
- Toggle XRefs
- Toggle Outcomes
- Edit Include Exclusions

Dry-run Include/XRef commands are intentionally hidden from the Activity Bar, but remain available from the Command Palette:

- `PreTeXt: Preview Include Toggle`
- `PreTeXt: Preview XRef Toggle`

## Exclusions

The include exclusion list remains a JSON array in `.vscode/settings.json`:

```json
{
  "pretextDevTools.excludedRefs": [
    "aa-bookends/front-matter.ptx"
  ]
}
```
