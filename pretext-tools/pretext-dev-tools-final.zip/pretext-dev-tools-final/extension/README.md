# PreTeXt Dev Tools extension

A small local VS Code extension for fast isolated PreTeXt development builds.

## Activity Bar actions

- **Toggle Includes** — globally turns eligible `xi:include` elements off or on.
- **Toggle XRefs** — globally changes live `xref ref="..."` attributes to tagged `provisional="..."` values or restores them.
- **Edit Include Exclusions** — opens workspace `settings.json` and, on first use, inserts an example `pretextDevTools.excludedRefs` JSON array if no workspace value exists yet.
- **Preview Include Toggle** — dry run.
- **Preview XRef Toggle** — dry run.

The extension expects the opened PreTeXt repository to contain:

```text
source/
scripts/toggle_xincludes.py
scripts/toggle_xrefs.py
```

## Run in Extension Development Host

Open this `extension/` folder in a VS Code WSL window and press **F5**. In the new Extension Development Host window, open the PreTeXt repository you want to work on.

No npm install or build step is required.
