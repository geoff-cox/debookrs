const vscode = require('vscode');
const path = require('path');

const EXAMPLE_EXCLUSIONS = [
    'aa-bookends/front-matter.ptx'
];

function getWorkspaceFolder() {
    const folders = vscode.workspace.workspaceFolders;

    if (!folders || folders.length === 0) {
        vscode.window.showErrorMessage(
            'Open a PreTeXt workspace before using PreTeXt Dev Tools.'
        );
        return undefined;
    }

    return folders[0];
}

async function assertWorkspaceFile(uri, label) {
    try {
        await vscode.workspace.fs.stat(uri);
        return true;
    } catch {
        vscode.window.showErrorMessage(`${label} not found: ${uri.fsPath}`);
        return false;
    }
}

async function runPythonTool({ scriptName, label, dryRun = false, includeExclusions = false }) {
    const folder = getWorkspaceFolder();
    if (!folder) {
        return;
    }

    if (!vscode.workspace.isTrusted) {
        vscode.window.showErrorMessage(
            'Trust this workspace before running PreTeXt development scripts.'
        );
        return;
    }

    const root = folder.uri.fsPath;
    const scriptUri = vscode.Uri.file(path.join(root, 'scripts', scriptName));
    const sourceUri = vscode.Uri.file(path.join(root, 'source'));

    if (!(await assertWorkspaceFile(scriptUri, 'Python script'))) {
        return;
    }

    if (!(await assertWorkspaceFile(sourceUri, 'PreTeXt source directory'))) {
        return;
    }

    const args = [scriptUri.fsPath, sourceUri.fsPath];

    if (includeExclusions) {
        const config = vscode.workspace.getConfiguration('pretextDevTools', folder.uri);
        const configured = config.get('excludedRefs', []);
        const excludedRefs = Array.isArray(configured)
            ? configured.filter(ref => typeof ref === 'string' && ref.trim().length > 0)
            : [];

        for (const ref of excludedRefs) {
            args.push('--exclude', ref.trim());
        }
    }

    if (dryRun) {
        args.push('--dry-run');
    }

    const execution = new vscode.ProcessExecution(
        'python3',
        args,
        { cwd: root }
    );

    const task = new vscode.Task(
        {
            type: 'pretextDevTools',
            script: scriptName,
            dryRun
        },
        vscode.TaskScope.Workspace,
        dryRun ? `Preview ${label}` : label,
        'PreTeXt Dev Tools',
        execution,
        []
    );

    task.presentationOptions = {
        reveal: vscode.TaskRevealKind.Always,
        panel: vscode.TaskPanelKind.Shared,
        clear: true,
        focus: false
    };

    await vscode.tasks.executeTask(task);
}

async function openWorkspaceSettings() {
    const folder = getWorkspaceFolder();
    if (!folder) {
        return;
    }

    const config = vscode.workspace.getConfiguration('pretextDevTools', folder.uri);
    const inspected = config.inspect('excludedRefs');

    // Put one editable example into .vscode/settings.json the first time this
    // command is used. If the user later changes the array (including to []),
    // it is never reinserted automatically.
    if (inspected && inspected.workspaceValue === undefined && inspected.workspaceFolderValue === undefined) {
        await config.update(
            'excludedRefs',
            EXAMPLE_EXCLUSIONS,
            vscode.ConfigurationTarget.Workspace
        );
    }

    await vscode.commands.executeCommand('workbench.action.openWorkspaceSettingsFile');
}

function activate(context) {
    context.subscriptions.push(
        vscode.commands.registerCommand(
            'pretextDevTools.toggleIncludes',
            () => runPythonTool({
                scriptName: 'toggle_xincludes.py',
                label: 'Toggle xi:include Comments',
                includeExclusions: true
            })
        ),

        vscode.commands.registerCommand(
            'pretextDevTools.previewIncludes',
            () => runPythonTool({
                scriptName: 'toggle_xincludes.py',
                label: 'xi:include Toggle',
                dryRun: true,
                includeExclusions: true
            })
        ),

        vscode.commands.registerCommand(
            'pretextDevTools.toggleXRefs',
            () => runPythonTool({
                scriptName: 'toggle_xrefs.py',
                label: 'Toggle xref Provisional References'
            })
        ),

        vscode.commands.registerCommand(
            'pretextDevTools.previewXRefs',
            () => runPythonTool({
                scriptName: 'toggle_xrefs.py',
                label: 'xref Toggle',
                dryRun: true
            })
        ),

        vscode.commands.registerCommand(
            'pretextDevTools.openWorkspaceSettings',
            openWorkspaceSettings
        )
    );
}

function deactivate() {}

module.exports = {
    activate,
    deactivate
};
