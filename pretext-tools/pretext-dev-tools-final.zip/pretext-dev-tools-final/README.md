# PreTeXt Dev Tools — clean proof-of-concept package

This package contains the final Level-1 proof of concept discussed in chat.

## Package layout

```text
pretext-dev-tools-final/
├── extension/
│   ├── .vscode/launch.json
│   ├── extension.js
│   ├── media/pretext-dev.svg
│   ├── package.json
│   └── README.md
└── workspace-example/
    ├── .vscode/settings.json
    └── scripts/
        ├── toggle_xincludes.py
        └── toggle_xrefs.py
```

## Put the workspace files in the PreTeXt repository

Copy these into the root of the book repository:

```text
workspace-example/scripts/toggle_xincludes.py -> scripts/toggle_xincludes.py
workspace-example/scripts/toggle_xrefs.py      -> scripts/toggle_xrefs.py
workspace-example/.vscode/settings.json        -> .vscode/settings.json
```

If `.vscode/settings.json` already exists, merge only this setting instead of replacing the file:

```json
"pretextDevTools.excludedRefs": [
  "aa-bookends/front-matter.ptx"
]
```

Each entry must exactly match an `href` value, for example:

```json
"pretextDevTools.excludedRefs": [
  "aa-bookends/front-matter.ptx",
  "aa-bookends/book-info.ptx"
]
```

## Start the extension

1. Open the `extension/` folder itself in a VS Code WSL window.
2. Press **F5** and choose **Run PreTeXt Dev Tools** if prompted.
3. In the Extension Development Host window, open the PreTeXt book repository.
4. Use the **PreTeXt Dev Tools** Activity Bar icon.

## Include toggle semantics

- If any eligible include is active, all eligible includes are commented out.
- If all eligible includes are already commented out, all eligible includes are uncommented.
- `pretextDevTools.excludedRefs` entries are ignored completely.
- Both `<xi:include href="x.ptx"/>` and `<xi:include href="x.ptx" />` are recognized.

## XRef toggle semantics

- Live `ref="foo"` becomes `provisional="__PTX_DEV_REF__:foo"`.
- Running again restores only those tagged provisional values to `ref="foo"`.
- Genuine provisional xrefs such as `<xref provisional="WORK-IN-PROGRESS"/>` are untouched.
- Xrefs inside XML comments and CDATA are untouched.
- Multiline xref opening tags are supported.

## Recommended safety check

Start from a clean Git tree. Toggle each feature off and then back on, and confirm that the final `git diff` contains no unintended changes.
