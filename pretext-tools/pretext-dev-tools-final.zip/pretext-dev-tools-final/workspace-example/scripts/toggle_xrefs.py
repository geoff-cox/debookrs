#!/usr/bin/env python3

import argparse
import re
from pathlib import Path


DEV_PREFIX = "__PTX_DEV_REF__:"


# XML comments and CDATA are matched before xref opening tags. Therefore an
# <xref> appearing inside one of these protected regions is never processed
# independently.
TOKEN_RE = re.compile(
    r'<!--.*?-->'
    r'|<!\[CDATA\[.*?\]\]>'
    r'|<xref\b(?:[^>"\']|"[^"]*"|\'[^\']*\')*>',
    re.DOTALL,
)


REF_ATTR_RE = re.compile(
    r'(?P<lead>\s)'
    r'ref'
    r'(?P<eq>\s*=\s*)'
    r'(?P<quote>["\'])'
    r'(?P<value>.*?)'
    r'(?P=quote)',
    re.DOTALL,
)


DEV_PROVISIONAL_ATTR_RE = re.compile(
    r'(?P<lead>\s)'
    r'provisional'
    r'(?P<eq>\s*=\s*)'
    r'(?P<quote>["\'])'
    + re.escape(DEV_PREFIX)
    + r'(?P<value>.*?)'
    r'(?P=quote)',
    re.DOTALL,
)


def is_protected_token(token: str) -> bool:
    return token.startswith("<!--") or token.startswith("<![CDATA[")


def has_live_ref(token: str) -> bool:
    return (
        not is_protected_token(token)
        and REF_ATTR_RE.search(token) is not None
    )


def has_dev_provisional(token: str) -> bool:
    return (
        not is_protected_token(token)
        and DEV_PROVISIONAL_ATTR_RE.search(token) is not None
    )


def disable_xref(token: str) -> tuple[str, int]:
    if is_protected_token(token):
        return token, 0

    def replacement(match: re.Match) -> str:
        return (
            f'{match.group("lead")}provisional'
            f'{match.group("eq")}{match.group("quote")}'
            f'{DEV_PREFIX}{match.group("value")}'
            f'{match.group("quote")}'
        )

    return REF_ATTR_RE.subn(replacement, token, count=1)


def enable_xref(token: str) -> tuple[str, int]:
    if is_protected_token(token):
        return token, 0

    def replacement(match: re.Match) -> str:
        return (
            f'{match.group("lead")}ref'
            f'{match.group("eq")}{match.group("quote")}'
            f'{match.group("value")}'
            f'{match.group("quote")}'
        )

    return DEV_PROVISIONAL_ATTR_RE.subn(replacement, token, count=1)


def inspect_text(text: str) -> tuple[bool, bool]:
    has_active = False
    has_disabled = False

    for match in TOKEN_RE.finditer(text):
        token = match.group(0)
        has_active |= has_live_ref(token)
        has_disabled |= has_dev_provisional(token)

    return has_active, has_disabled


def transform_text(text: str, target: str) -> tuple[str, int]:
    output: list[str] = []
    position = 0
    total = 0

    for match in TOKEN_RE.finditer(text):
        output.append(text[position:match.start()])
        token = match.group(0)

        if target == "off":
            modified, count = disable_xref(token)
        else:
            modified, count = enable_xref(token)

        output.append(modified)
        total += count
        position = match.end()

    output.append(text[position:])
    return "".join(output), total


def read_file(path: Path) -> str:
    with path.open("r", encoding="utf-8", newline="") as file:
        return file.read()


def write_file(path: Path, text: str) -> None:
    with path.open("w", encoding="utf-8", newline="") as file:
        file.write(text)


def find_source_files(root: Path) -> list[Path]:
    return sorted(
        {
            path
            for pattern in ("*.ptx", "*.xml")
            for path in root.rglob(pattern)
        }
    )


def determine_target(texts: dict[Path, str]) -> str | None:
    has_active = False
    has_disabled = False

    for text in texts.values():
        active, disabled = inspect_text(text)
        has_active |= active
        has_disabled |= disabled

    if has_active:
        return "off"

    if has_disabled:
        return "on"

    return None


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Globally toggle live PreTeXt xrefs between @ref and tagged "
            "development @provisional values. Xrefs inside XML comments and "
            "CDATA are ignored. Genuine provisional xrefs are left untouched."
        )
    )

    parser.add_argument(
        "root",
        nargs="?",
        type=Path,
        default=Path("source"),
        help="Directory to search (default: source)",
    )

    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would change without modifying files.",
    )

    args = parser.parse_args()

    if not args.root.exists():
        raise SystemExit(f"Directory does not exist: {args.root}")

    files = find_source_files(args.root)

    if not files:
        raise SystemExit(f"No .ptx or .xml files found under {args.root}")

    texts = {path: read_file(path) for path in files}
    target = determine_target(texts)

    if target is None:
        print("No active or development-disabled xrefs found.")
        return

    print(f"Target state: {target.upper()}")
    print()

    total_files = 0
    total_changes = 0

    for path, original in texts.items():
        modified, count = transform_text(original, target)

        if not count:
            continue

        total_files += 1
        total_changes += count
        prefix = "[DRY RUN] " if args.dry_run else ""
        print(f"{prefix}{path}: {count} xref(s)")

        if not args.dry_run:
            write_file(path, modified)

    print()
    print(f"Files affected: {total_files}")
    print(f"Xrefs changed: {total_changes}")


if __name__ == "__main__":
    main()
