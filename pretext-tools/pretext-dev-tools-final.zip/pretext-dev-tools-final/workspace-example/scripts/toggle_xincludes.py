#!/usr/bin/env python3

import argparse
import re
from pathlib import Path


EXCLUDED_REFS: set[str] = set()


XI_INCLUDE_PATTERN = re.compile(
    r'(?m)^(?P<indent>[ \t]*)(?:'
    r'<xi:include\s+href="(?P<active>[^"]+)"(?P<active_space>[ \t]*)/>'
    r'|'
    r'<!--[ \t]*<xi:include\s+href="(?P<commented>[^"]+)"(?P<commented_space>[ \t]*)/>[ \t]*-->'
    r')[ \t]*$'
)


def get_href(match: re.Match) -> str:
    return match.group("active") or match.group("commented")


def is_excluded(href: str) -> bool:
    return href in EXCLUDED_REFS


def find_global_target(files: list[Path]) -> str:
    """
    If any eligible xi:include is active, turn all eligible includes OFF.
    Otherwise, turn all eligible includes ON.
    """
    for path in files:
        with path.open("r", encoding="utf-8", newline="") as file:
            text = file.read()

        for match in XI_INCLUDE_PATTERN.finditer(text):
            href = get_href(match)

            if is_excluded(href):
                continue

            if match.group("active") is not None:
                return "off"

    return "on"


def transform_match(match: re.Match, target: str) -> str:
    indent = match.group("indent")
    href = get_href(match)

    if is_excluded(href):
        return match.group(0)

    spacing = (
        match.group("active_space")
        if match.group("active") is not None
        else match.group("commented_space")
    )

    include = f'<xi:include href="{href}"{spacing}/>'

    if target == "off":
        return f'{indent}<!-- {include} -->'

    return f'{indent}{include}'


def process_file(path: Path, target: str, dry_run: bool = False) -> int:
    with path.open("r", encoding="utf-8", newline="") as file:
        original = file.read()

    modified = XI_INCLUDE_PATTERN.sub(
        lambda match: transform_match(match, target),
        original,
    )

    if modified == original:
        return 0

    changed = sum(
        old != new
        for old, new in zip(
            original.splitlines(),
            modified.splitlines(),
        )
    )

    if not dry_run:
        with path.open("w", encoding="utf-8", newline="") as file:
            file.write(modified)

    return changed


def find_source_files(root: Path) -> list[Path]:
    return sorted(
        {
            path
            for pattern in ("*.ptx", "*.xml")
            for path in root.rglob(pattern)
        }
    )


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Globally toggle PreTeXt xi:include lines. If any eligible include "
            "is active, all eligible includes are commented; otherwise all "
            "eligible includes are uncommented."
        )
    )

    parser.add_argument(
        "root",
        nargs="?",
        type=Path,
        default=Path("source"),
        help="Directory to search (default: source)",
    )

    parser.add_argument(
        "--exclude",
        action="append",
        default=[],
        help=(
            "Exact xi:include href value to leave untouched. "
            "May be supplied multiple times."
        ),
    )

    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would change without modifying files.",
    )

    args = parser.parse_args()

    EXCLUDED_REFS.clear()
    EXCLUDED_REFS.update(
        ref.strip()
        for ref in args.exclude
        if ref.strip()
    )

    if not args.root.exists():
        raise SystemExit(f"Directory does not exist: {args.root}")

    files = find_source_files(args.root)

    if not files:
        raise SystemExit(f"No .ptx or .xml files found under {args.root}")

    target = find_global_target(files)

    print(f"Target state: {target.upper()}")

    if EXCLUDED_REFS:
        print("Excluded refs:")
        for ref in sorted(EXCLUDED_REFS):
            print(f"  - {ref}")

    print()

    total_files = 0
    total_changes = 0

    for path in files:
        count = process_file(path, target=target, dry_run=args.dry_run)

        if count:
            total_files += 1
            total_changes += count
            prefix = "[DRY RUN] " if args.dry_run else ""
            print(f"{prefix}{path}: changed {count} include(s)")

    print()
    print(f"Files affected: {total_files}")
    print(f"Includes changed: {total_changes}")


if __name__ == "__main__":
    main()
